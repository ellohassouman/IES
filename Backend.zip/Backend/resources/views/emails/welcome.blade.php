<div id="mail"><div>
    <table width="100%" height="100%" border="0" style="background-color: rgba(246, 246, 246, 1); padding: 0; margin: 0">
        <tbody><tr>
            <td style="padding: 0; margin: 0; vertical-align: top">
                <table width="100%" border="0" style="text-align: center; padding: 0; margin: 0; vertical-align: top">
                    <tbody><tr>
                        <td style="padding: 0; margin: 0; vertical-align: top">
                            <table border="0" cellspacing="0" cellpadding="0" width="698" style="background-color: rgba(255, 255, 255, 1); padding: 0; margin: 0; vertical-align: top">
                                <tbody><tr>
                                    <td style="padding: 0; margin: 0; vertical-align: top">
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: rgba(255, 255, 255, 1)">
                                            <tbody><tr>
                                                <td style="padding: 0; margin: 0; vertical-align: top">
                                                    <img width="40" height="98" style="display: block">
                                                </td>
                                                <td style="padding: 0; margin: 0; vertical-align: top">
                                                    <img width="200" height="98" style="display: block">
                                                </td>
                                                <td style="padding: 0; margin: 0; vertical-align: top">
                                                    <img width="458" height="98" style="display: block">
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 0; margin: 0; vertical-align: top">
                                        <table border="0" cellspacing="0" cellpadding="0" width="100%" style="padding: 0; margin: 0; vertical-align: top">
                                            <tbody><tr>
                                                <td width="239" style="padding: 0; margin: 0; vertical-align: top"></td>
                                                <td width="460" style="padding: 0; margin: 0; vertical-align: top">
                                                    <table border="0" cellspacing="0" cellpadding="0" width="100%" style="padding: 0; margin: 0; vertical-align: top">
                                                        <tbody><tr>
                                                            <td style="padding: 0; margin: 0; vertical-align: top; font-size: 16pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; color: rgba(102, 170, 200, 1)">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 0; margin: 0; vertical-align: top; font-size: 16pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; color: rgba(102, 170, 200, 1)">
                                                                <table width="100%" border="0" style="padding: 0; margin: 0; vertical-align: top; font-size: 13pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; font-weight: bold; color: rgba(102, 170, 200, 1)">
                                                                    <tbody><tr>
                                                                        <td style="padding: 0; margin: 0; vertical-align: top">Account Information</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                                    </tr>
                                                                </tbody></table>
                                                            </td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 0; margin: 0; vertical-align: top">
                                        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="padding: 0; margin: 0">
                                            <tbody><tr>
                                                <td style="padding: 0; margin: 0; vertical-align: top">
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width: 100%">
                                                        <tbody><tr>
                                                            <td style="font-size: 13pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; font-weight: bold; color: rgba(102, 170, 200, 1); padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                            <td style="font-size: 13pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; font-weight: bold; color: rgba(102, 170, 200, 1); padding: 0; margin: 0; vertical-align: top">
                                                              <p style="word-break: break-all; text-align: left">
Bonjour {{ $userEmail }},<br><br>Nous avons bien reçu votre demande d'ouverture d'un compte utilisateur sur IPAKI External Site (IES). <br>Afin de finaliser le processus, veuillez cliquer sur le lien d'activation ci-dessous :<br><br><a href="{{ $confirmationLink }}">link</a><br><br>Après cette étape, vous recevrez un autre e-mail vous informant de la validation de votre compte sur IES. <br><br>Cordialement,<br>L'équipe de support                                                              </p>
                                                            </td>
                                                            <td style="font-size: 13pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; font-weight: bold; color: rgba(102, 170, 200, 1); padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                            <td style="padding: 0; margin: 0; vertical-align: top">
                                                                <table width="100%" border="0" style="font-size: 10pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; color: rgba(102, 102, 102, 1); padding: 0; margin: 0; vertical-align: top">
                                                                    <tbody><tr>
                                                                        <td style="padding: 0; margin: 0; vertical-align: top">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                                    </tr>
                                                                </tbody></table>
                                                            </td>
                                                            <td style="padding: 0; margin: 0; vertical-align: top">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 0; margin: 0; vertical-align: top"></td>
                                                            <td style="padding: 0; margin: 0; vertical-align: top"></td>
                                                            <td style="padding: 0; margin: 0; vertical-align: top"></td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 0; margin: 0; vertical-align: top">
                                        <img width="698" height="98" style="display: block">
                                    </td>
                                </tr>
                                <tr style="text-align: center">
                                    <td style="font-size: 7pt; font-family: &quot;Verdana&quot;, &quot;sans-serif&quot;; color: rgba(102, 102, 102, 1); vertical-align: top; padding: 0; margin: 0">
                                        This is an automatic email, please dont answer.
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                </tbody></table>
            </td>
        </tr>
    </tbody></table>
</div></div>
