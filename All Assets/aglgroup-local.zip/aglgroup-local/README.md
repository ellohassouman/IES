# AGLGroup Extranet - Site Local

Téléchargé le: 18/11/2025 22:03:38

## Structure:
- pages/ : 60 pages HTML
- assets/css/ : Feuilles de style
- assets/js/ : Scripts JavaScript
- assets/images/ : Images
- assets/fonts/ : Polices
- cookies.json : Session cookies

## Pages téléchargées:
- https://ies.aglgroup.com/ATLCIVP/Home
- https://ies.aglgroup.com/ATLCIVP/Home#
- https://ies.aglgroup.com/ATLCIVP/Customer/MyProfile
- https://ies.aglgroup.com/ATLCIVP/Payment/History
- https://ies.aglgroup.com/ATLCIVP/Account/ChangePassword
- https://ies.aglgroup.com/ATLCIVP/Support/ShowSupportDialog
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=AEV0238293
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=AEV0239463
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG08737243
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG08802405
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG09585368
- https://ies.aglgroup.com/ATLCIVP/Register?Length=7
- https://ies.aglgroup.com/ATLCIVP/ForgotPassword?SubmitAction=ForgotPasswordCustomer&CancelAction=CustomerLogin
- https://ies.aglgroup.com/ATLCIVP/Account/ChangePassword#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=AEV0238293#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0238293
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=541982&blNumber=AEV0238293
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=541982&blNumber=AEV0238293
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=AEV0239463#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0239463
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=540237&blNumber=AEV0239463
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=540237&blNumber=AEV0239463
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG08737243#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08737243
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=424822&blNumber=EBKG08737243
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=424822&blNumber=EBKG08737243
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG08802405#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08802405
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=417835&blNumber=EBKG08802405
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=417835&blNumber=EBKG08802405
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingDetails?blNumber=EBKG09585368#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG09585368
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=429825&blNumber=EBKG09585368
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=429825&blNumber=EBKG09585368
- https://ies.aglgroup.com/ATLCIVP/Register?Length=7#
- https://ies.aglgroup.com/ATLCIVP/Login?Length=7
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0238293#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0238293#collapseProforma_1229941
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=541982&blNumber=AEV0238293#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=541982&blNumber=AEV0238293#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=541982&blNumber=AEV0238293#dc1260889
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0239463#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=AEV0239463#collapseInvoice_1229924
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=540237&blNumber=AEV0239463#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=540237&blNumber=AEV0239463#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=540237&blNumber=AEV0239463#dc1347576
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08737243#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08737243#collapseInvoice_1023119
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=424822&blNumber=EBKG08737243#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=424822&blNumber=EBKG08737243#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=424822&blNumber=EBKG08737243#dc1030643
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08802405#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG08802405#collapseInvoice_1001104
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=417835&blNumber=EBKG08802405#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=417835&blNumber=EBKG08802405#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=417835&blNumber=EBKG08802405#dc963041
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG09585368#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingInvoices?blNumber=EBKG09585368#collapseInvoice_1023118
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingPendingInvoicing?blId=429825&blNumber=EBKG09585368#
- https://ies.aglgroup.com/ATLCIVP/Customer/BillOfLadingYITrakingInfo?blId=429825&blNumber=EBKG09585368#

## Ressources:
- Total: 50 fichiers
