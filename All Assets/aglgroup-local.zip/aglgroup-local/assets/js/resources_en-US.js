var resources = {
    Edit: 'Edit',
    Delete: 'Delete',
    AreYouSureWantToDeleteTheRecord: 'Are you sure want to delete the record?'
}